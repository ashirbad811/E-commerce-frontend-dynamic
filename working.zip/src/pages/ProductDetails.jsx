import React, { useState, useEffect, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import Swal from "sweetalert2";
import { CartContext } from "../context/CartContext";

const ProductDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useContext(CartContext);
  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProduct();
  }, [id]);

  const fetchProduct = async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `http://localhost:5000/api/products/${id}`,
      );
      setProduct(response.data);
    } catch (err) {
      Swal.fire("Error", "Product not found", "error");
      navigate("/shop");
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = () => {
    if (quantity <= 0) {
      Swal.fire("Error", "Please select a valid quantity", "error");
      return;
    }

    if (quantity > product.stock) {
      Swal.fire(
        "Error",
        `Only ${product.stock} items available in stock`,
        "error",
      );
      return;
    }

    addToCart(product, quantity);
    Swal.fire({
      title: "Added to Cart!",
      text: `${quantity} × ${product.name} added to your cart`,
      icon: "success",
      showCancelButton: true,
      confirmButtonText: "Go to Cart",
      cancelButtonText: "Continue Shopping",
    }).then((result) => {
      if (result.isConfirmed) {
        navigate("/cart");
      } else {
        setQuantity(1);
      }
    });
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-20">
        <p className="text-gray-600">Loading product...</p>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="flex justify-center items-center py-20">
        <p className="text-gray-600">Product not found</p>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      <button
        onClick={() => navigate("/shop")}
        className="mb-6 text-blue-600 hover:text-blue-800 font-semibold"
      >
        ← Back to Shop
      </button>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Product Image */}
        <div className="flex justify-center items-center bg-gray-100 rounded-lg p-8">
          {product.image_url ? (
            <img
              src={`http://localhost:5000${product.image_url}`}
              alt={product.name}
              className="max-w-full max-h-96 object-contain"
            />
          ) : (
            <div className="w-full h-96 flex items-center justify-center text-gray-400">
              No image available
            </div>
          )}
        </div>

        {/* Product Details */}
        <div className="space-y-6">
          <div>
            <h1 className="text-4xl font-bold mb-2">{product.name}</h1>
            <p className="text-gray-600 text-lg">{product.description}</p>
          </div>

          {/* Price and Stock */}
          <div className="bg-gray-50 p-6 rounded-lg">
            <p className="text-3xl font-bold text-green-600 mb-2">
              ${product.price}
            </p>
            <p
              className={`text-lg font-semibold ${product.stock > 0 ? "text-green-600" : "text-red-600"}`}
            >
              {product.stock > 0 ? `${product.stock} in stock` : "Out of stock"}
            </p>
          </div>

          {/* Product Attributes */}
          <div className="space-y-3">
            {product.color && (
              <div>
                <label className="text-gray-700 font-semibold">Color:</label>
                <p className="text-gray-600">{product.color}</p>
              </div>
            )}
            {product.size && (
              <div>
                <label className="text-gray-700 font-semibold">Size:</label>
                <p className="text-gray-600">{product.size}</p>
              </div>
            )}
          </div>

          {/* Quantity Selector */}
          {product.stock > 0 && (
            <div className="space-y-4">
              <div>
                <label className="block text-gray-700 font-semibold mb-2">
                  Quantity:
                </label>
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="bg-gray-300 hover:bg-gray-400 text-black px-4 py-2 rounded"
                  >
                    -
                  </button>
                  <input
                    type="number"
                    min="1"
                    max={product.stock}
                    value={quantity}
                    onChange={(e) => {
                      const val = parseInt(e.target.value) || 1;
                      setQuantity(Math.min(Math.max(val, 1), product.stock));
                    }}
                    className="w-20 px-3 py-2 border rounded text-center"
                  />
                  <button
                    onClick={() =>
                      setQuantity(Math.min(product.stock, quantity + 1))
                    }
                    className="bg-gray-300 hover:bg-gray-400 text-black px-4 py-2 rounded"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Add to Cart Button */}
              <button
                onClick={handleAddToCart}
                className="w-full bg-blue-600 text-white py-3 rounded-lg font-bold text-lg hover:bg-blue-700 transition"
              >
                Add to Cart
              </button>
            </div>
          )}

          {/* Out of Stock Message */}
          {product.stock === 0 && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
              This product is currently out of stock
            </div>
          )}

          {/* Additional Info */}
          <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
            <h3 className="font-bold text-blue-900 mb-2">✓ Free Shipping</h3>
            <h3 className="font-bold text-blue-900 mb-2">✓ 30-Day Returns</h3>
            <h3 className="font-bold text-blue-900">
              ✓ Cash on Delivery Available
            </h3>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;
