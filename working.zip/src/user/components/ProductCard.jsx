import React, { useState, useContext } from "react";
import { Link } from "react-router-dom";
import { CartContext } from "../../context/CartContext";
import Swal from "sweetalert2";

const ProductCard = ({ product }) => {
  const { addToCart } = useContext(CartContext);
  const [quantity, setQuantity] = useState(1);

  const handleAddToCart = () => {
    addToCart(product, quantity);
    Swal.fire({
      position: "top-end",
      icon: "success",
      title: "Added to cart",
      showConfirmButton: false,
      timer: 1500,
    });
    setQuantity(1);
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition">
      {product.image_url && (
        <Link to={`/product/${product.id}`}>
          <img
            src={`${import.meta.env.VITE_API_BASE_URL}${product.image_url}`}
            alt={product.name}
            className="w-full h-48 object-cover hover:scale-105 transition"
          />
        </Link>
      )}

      <div className="p-4">
        <Link to={`/product/${product.id}`} className="hover:text-blue-600">
          <h3 className="font-bold text-lg mb-2">{product.name}</h3>
        </Link>

        <p className="text-gray-600 text-sm mb-3 line-clamp-2">
          {product.description}
        </p>

        <div className="flex justify-between items-center mb-3">
          <span className="text-2xl font-bold text-green-600">
            ₹{product.price}
          </span>
          <span className="text-sm text-gray-600">Stock: {product.stock}</span>
        </div>

        {product.color && (
          <p className="text-sm text-gray-600 mb-2">Color: {product.color}</p>
        )}
        {product.size && (
          <p className="text-sm text-gray-600 mb-3">Size: {product.size}</p>
        )}

        <div className="flex gap-2">
          <input
            type="number"
            min="1"
            max={product.stock}
            value={quantity}
            onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
            className="w-16 border p-2 rounded text-center"
          />
          <button
            onClick={handleAddToCart}
            disabled={product.stock === 0}
            className="flex-1 bg-blue-600 text-white py-2 rounded hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed font-semibold"
          >
            {product.stock === 0 ? "Out of Stock" : "Add to Cart"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
