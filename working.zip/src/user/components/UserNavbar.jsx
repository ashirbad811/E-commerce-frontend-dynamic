import React, { useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../../context/AuthContext";
import { CartContext } from "../../context/CartContext";

const UserNavbar = () => {
  const { user, logout } = useContext(AuthContext);
  const { getTotalItems } = useContext(CartContext);
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
  };

  return (
    <nav className="bg-gradient-to-r from-blue-600 to-blue-800 text-white shadow-lg sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <Link to="/" className="text-2xl font-bold">
            🛍️ TeeStore
          </Link>

          <div className="flex items-center gap-6">
            <Link to="/" className="hover:text-blue-100 transition">
              Home
            </Link>
            <Link to="/shop" className="hover:text-blue-100 transition">
              Shop
            </Link>

            {user ? (
              <>
                <Link
                  to="/cart"
                  className="relative hover:text-blue-100 transition"
                >
                  🛒 Cart
                  {getTotalItems() > 0 && (
                    <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                      {getTotalItems()}
                    </span>
                  )}
                </Link>

                <Link
                  to="/dashboard"
                  className="hover:text-blue-100 transition"
                >
                  👤 {user.name}
                </Link>

                <button
                  onClick={handleLogout}
                  className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded transition"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/cart"
                  className="relative hover:text-blue-100 transition"
                >
                  🛒 Cart
                </Link>
                <Link
                  to="/login"
                  className="bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded transition"
                >
                  Login
                </Link>
                <Link
                  to="/register"
                  className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded transition"
                >
                  Register
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default UserNavbar;
