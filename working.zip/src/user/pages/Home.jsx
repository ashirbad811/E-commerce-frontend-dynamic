import React from "react";
import { Link } from "react-router-dom";
import HeroSection from "../../pages/HeroSection";
import NewArrivals from "../../components/NewArrivals";
import PopularProducts from "../../components/PopularProducts";

const Home = () => {
  return (
    <div>
      <HeroSection />
      <NewArrivals />
      <PopularProducts />
    </div>
  );
};

export default Home;
