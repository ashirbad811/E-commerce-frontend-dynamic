import React, { useState, useContext, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../../context/AuthContext";
import { CartContext } from "../../context/CartContext";
import { WishlistContext } from "../../context/WishlistContext";
import {
  FiSearch,
  FiShoppingCart,
  FiUser,
  FiLogOut,
  FiMenu,
  FiX,
  FiHome,
  FiGrid,
  FiPackage,
  FiHeart,
} from "react-icons/fi";
import axios from "axios";

const UserNavbar = ({ onNeedLogin }) => {
  const { user, logout } = useContext(AuthContext);
  const { getTotalItems } = useContext(CartContext);
  const { getTotalItems: getWishlistTotal } = useContext(WishlistContext);
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [categories, setCategories] = useState([]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await axios.get(
          `${import.meta.env.VITE_API_URL || "http://localhost:5000"}/api/categories`,
        );
        setCategories(response.data.slice(0, 6)); // Show top 6 categories
      } catch (error) {
        console.error("Error fetching categories:", error);
      }
    };
    fetchCategories();
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery)}`);
      setSearchQuery("");
      setMobileMenuOpen(false);
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate("/");
    setShowProfileMenu(false);
  };

  const cartCount = getTotalItems();
  const wishlistCount = getWishlistTotal();

  return (
    <>
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 to-blue-800 text-white sticky top-0 z-40 shadow-lg">
        <div className="w-full">
          {/* Top Bar - Desktop */}
          <div className="hidden md:flex items-center justify-between h-16 px-4 max-w-7xl mx-auto">
            {/* Logo */}
            <Link
              to="/"
              className="flex items-center space-x-2 font-bold text-2xl hover:text-blue-100 transition"
            >
              <FiGrid className="text-yellow-400" size={28} />
              <span>ShopHub</span>
            </Link>

            {/* Search Bar */}
            <form
              onSubmit={handleSearch}
              className="flex-1 mx-6 relative bg-white rounded-lg overflow-hidden shadow-md"
            >
              <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search for products, brands, and more"
                className="w-full pl-10 pr-14 py-2 text-gray-800 focus:outline-none"
              />
              <button
                type="submit"
                className="absolute right-1 top-1/2 transform -translate-y-1/2 bg-yellow-400 text-gray-800 p-2 rounded hover:bg-yellow-500 transition"
              >
                <FiSearch size={18} />
              </button>
            </form>

            {/* Right Actions */}
            <div className="flex items-center space-x-4">
              {user ? (
                <div className="relative">
                  <button
                    onClick={() => setShowProfileMenu(!showProfileMenu)}
                    className="flex items-center space-x-1 hover:bg-blue-700 px-3 py-2 rounded transition"
                  >
                    <FiUser size={20} />
                    <span className="text-sm font-medium">
                      {user.name?.split(" ")[0]}
                    </span>
                  </button>

                  {/* Profile Dropdown */}
                  {showProfileMenu && (
                    <div className="absolute right-0 mt-2 w-48 bg-white text-gray-800 rounded-lg shadow-xl py-2 z-50">
                      <Link
                        to="/dashboard"
                        className="flex items-center space-x-2 px-4 py-2 hover:bg-blue-50 transition text-sm"
                        onClick={() => setShowProfileMenu(false)}
                      >
                        <FiPackage size={18} />
                        <span>My Orders</span>
                      </Link>
                      <hr className="my-1" />
                      <button
                        onClick={handleLogout}
                        className="w-full text-left flex items-center space-x-2 px-4 py-2 hover:bg-blue-50 transition text-sm"
                      >
                        <FiLogOut size={18} />
                        <span>Logout</span>
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <button
                  onClick={() => navigate("/login")}
                  className="flex items-center space-x-1 hover:bg-blue-700 px-3 py-2 rounded transition"
                >
                  <FiUser size={20} />
                  <span className="text-sm font-medium">Login</span>
                </button>
              )}

              {/* Wishlist */}
              <Link
                to="/wishlist"
                className="relative flex items-center space-x-1 hover:bg-blue-700 px-3 py-2 rounded transition"
              >
                <FiHeart size={20} />
                <span className="text-sm font-medium">Wishlist</span>
                {wishlistCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                    {wishlistCount}
                  </span>
                )}
              </Link>

              {/* Cart */}
              <Link
                to="/cart"
                className="relative flex items-center space-x-1 hover:bg-blue-700 px-3 py-2 rounded transition"
              >
                <FiShoppingCart size={20} />
                <span className="text-sm font-medium">Cart</span>
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-yellow-400 text-gray-800 text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </Link>
            </div>
          </div>

          {/* Categories Bar */}
          <div className="hidden md:flex items-center space-x-1 border-t border-blue-500 py-2 px-4 max-w-7xl mx-auto overflow-x-auto">
            <Link
              to="/"
              className="flex items-center space-x-1 px-3 py-1 hover:bg-blue-700 rounded text-sm whitespace-nowrap transition"
            >
              <FiHome size={16} />
              <span>Home</span>
            </Link>

            {categories.map((cat) => (
              <Link
                key={cat.id}
                to={`/products?category=${cat.id}`}
                className="px-3 py-1 hover:bg-blue-700 rounded text-sm whitespace-nowrap transition"
              >
                {cat.icon && <span>{cat.icon}</span>}
                {cat.name}
              </Link>
            ))}

            <Link
              to="/products"
              className="px-3 py-1 hover:bg-blue-700 rounded text-sm whitespace-nowrap transition ml-auto"
            >
              View All
            </Link>
          </div>

          {/* Mobile Header */}
          <div className="md:hidden flex items-center justify-between h-14 px-4">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="hover:bg-blue-700 p-2 rounded transition"
            >
              {mobileMenuOpen ? <FiX size={24} /> : <FiMenu size={24} />}
            </button>

            <Link
              to="/"
              className="flex items-center space-x-1 font-bold text-lg hover:text-blue-100 transition"
            >
              <FiGrid className="text-yellow-400" size={24} />
              <span>ShopHub</span>
            </Link>

            <div className="flex items-center space-x-2">
              <Link
                to="/wishlist"
                className="relative flex items-center hover:bg-blue-700 p-2 rounded transition"
              >
                <FiHeart size={20} />
                {wishlistCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                    {wishlistCount}
                  </span>
                )}
              </Link>

              <Link
                to="/cart"
                className="relative flex items-center hover:bg-blue-700 p-2 rounded transition"
              >
                <FiShoppingCart size={20} />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-yellow-400 text-gray-800 text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </Link>

              {user ? (
                <div className="relative">
                  <button
                    onClick={() => setShowProfileMenu(!showProfileMenu)}
                    className="hover:bg-blue-700 p-2 rounded transition"
                  >
                    <FiUser size={20} />
                  </button>

                  {showProfileMenu && (
                    <div className="absolute right-0 mt-2 w-40 bg-white text-gray-800 rounded-lg shadow-lg py-2 z-50">
                      <Link
                        to="/dashboard"
                        className="flex items-center space-x-2 px-4 py-2 hover:bg-blue-50 text-sm transition"
                        onClick={() => setShowProfileMenu(false)}
                      >
                        <FiPackage size={16} />
                        <span>My Orders</span>
                      </Link>
                      <hr className="my-1" />
                      <button
                        onClick={handleLogout}
                        className="w-full text-left flex items-center space-x-2 px-4 py-2 hover:bg-blue-50 text-sm transition"
                      >
                        <FiLogOut size={16} />
                        <span>Logout</span>
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <button
                  onClick={() => navigate("/login")}
                  className="hover:bg-blue-700 p-2 rounded transition"
                >
                  <FiUser size={20} />
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white text-gray-800 border-b border-gray-200 shadow-md z-30 max-h-96 overflow-y-auto">
          {/* Search */}
          <form
            onSubmit={handleSearch}
            className="p-4 border-b border-gray-200"
          >
            <div className="relative">
              <FiSearch className="absolute left-3 top-3 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search products..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-600"
              />
            </div>
          </form>

          {/* Links */}
          <nav className="p-4 space-y-2">
            <Link
              to="/"
              className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 font-medium p-2 hover:bg-blue-50 rounded transition"
              onClick={() => setMobileMenuOpen(false)}
            >
              <FiHome size={20} />
              <span>Home</span>
            </Link>

            {categories.map((cat) => (
              <Link
                key={cat.id}
                to={`/products?category=${cat.id}`}
                className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 font-medium p-2 hover:bg-blue-50 rounded transition"
                onClick={() => setMobileMenuOpen(false)}
              >
                <span className="text-lg">{cat.icon}</span>
                <span>{cat.name}</span>
              </Link>
            ))}

            <Link
              to="/products"
              className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 font-medium p-2 hover:bg-blue-50 rounded transition"
              onClick={() => setMobileMenuOpen(false)}
            >
              <FiGrid size={20} />
              <span>View All Products</span>
            </Link>

            <Link
              to="/wishlist"
              className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 font-medium p-2 hover:bg-blue-50 rounded transition"
              onClick={() => setMobileMenuOpen(false)}
            >
              <FiHeart size={20} />
              <span>My Wishlist</span>
              {wishlistCount > 0 && (
                <span className="ml-auto bg-red-500 text-white text-xs font-bold rounded-full h-6 w-6 flex items-center justify-center">
                  {wishlistCount}
                </span>
              )}
            </Link>

            {!user && (
              <Link
                to="/login"
                className="flex items-center space-x-2 text-blue-600 hover:text-blue-800 font-bold mt-4 pt-4 p-2 border-t border-gray-200 hover:bg-blue-50 rounded transition"
                onClick={() => setMobileMenuOpen(false)}
              >
                <FiUser size={20} />
                <span>Login / Register</span>
              </Link>
            )}
          </nav>
        </div>
      )}
    </>
  );
};

export default UserNavbar;
