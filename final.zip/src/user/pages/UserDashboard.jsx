import React, { useContext, useState, useEffect } from "react";
import { AuthContext } from "../../context/AuthContext";
import axios from "axios";
import Swal from "sweetalert2";
import {
  FiPackage,
  FiTruck,
  FiCheckCircle,
  FiXCircle,
  FiSearch,
} from "react-icons/fi";

const UserDashboard = () => {
  const { user } = useContext(AuthContext);
  const [orders, setOrders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [orderItems, setOrderItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  useEffect(() => {
    fetchOrders();
  }, []);

  useEffect(() => {
    filterOrders();
  }, [orders, searchTerm, statusFilter]);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/api/orders`,
        {
          withCredentials: true,
        },
      );
      setOrders(response.data);
    } catch (err) {
      console.error("Error fetching orders:", err);
      Swal.fire("Error", "Failed to fetch orders", "error");
    } finally {
      setLoading(false);
    }
  };

  const filterOrders = () => {
    let filtered = orders;

    // Filter by status
    if (statusFilter !== "all") {
      filtered = filtered.filter((order) => order.status === statusFilter);
    }

    // Search by order ID
    if (searchTerm) {
      filtered = filtered.filter((order) =>
        order.id.toString().includes(searchTerm),
      );
    }

    setFilteredOrders(filtered);
  };

  const handleViewOrderDetails = async (orderId) => {
    try {
      const response = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/api/orders/${orderId}`,
        {
          withCredentials: true,
        },
      );
      setSelectedOrder(response.data);
      setOrderItems(response.data.items || []);
    } catch (err) {
      console.error("Error fetching order details:", err);
      Swal.fire("Error", "Failed to fetch order details", "error");
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "delivered":
        return "bg-green-100 text-green-800";
      case "shipped":
        return "bg-blue-100 text-blue-800";
      case "confirmed":
        return "bg-yellow-100 text-yellow-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case "delivered":
        return <FiCheckCircle className="text-green-600 text-2xl" />;
      case "shipped":
        return <FiTruck className="text-blue-600 text-2xl" />;
      case "confirmed":
        return <FiPackage className="text-yellow-600 text-2xl" />;
      case "cancelled":
        return <FiXCircle className="text-red-600 text-2xl" />;
      default:
        return <FiPackage className="text-gray-600 text-2xl" />;
    }
  };

  const getStatusDescription = (status) => {
    const descriptions = {
      confirmed: "Your order has been confirmed. We're preparing it.",
      shipped: "Your order is on its way. Track it with our partners.",
      delivered: "Your order has been delivered. Hope you enjoy!",
      cancelled: "This order has been cancelled.",
    };
    return descriptions[status] || "Order status pending.";
  };

  const orderStats = {
    total: orders.length,
    pending: orders.filter((o) => o.status === "confirmed").length,
    shipped: orders.filter((o) => o.status === "shipped").length,
    delivered: orders.filter((o) => o.status === "delivered").length,
  };

  return (
    <div className="bg-gray-50 min-h-screen py-8">
      <div className="max-w-6xl mx-auto px-4">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            Welcome, {user?.name}!
          </h1>
          <p className="text-gray-600">
            Manage your orders and track deliveries
          </p>
        </div>

        {selectedOrder ? (
          <>
            {/* Order Details View */}
            <button
              onClick={() => setSelectedOrder(null)}
              className="mb-6 text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-2"
            >
              ← Back to Orders
            </button>

            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-600">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h2 className="text-3xl font-bold">
                    Order #{selectedOrder.id}
                  </h2>
                  <p className="text-gray-600 text-sm">
                    Placed on{" "}
                    {new Date(selectedOrder.created_at).toLocaleDateString()}
                  </p>
                </div>
                <span
                  className={`inline-block px-4 py-2 rounded-full text-sm font-semibold ${getStatusColor(selectedOrder.status)}`}
                >
                  {selectedOrder.status.toUpperCase()}
                </span>
              </div>

              {/* Status Description */}
              <div className="bg-blue-50 border border-blue-200 rounded p-4 mb-6">
                <p className="text-blue-700">
                  {getStatusDescription(selectedOrder.status)}
                </p>
              </div>

              {/* Order Information Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6 pb-6 border-b">
                <div>
                  <h4 className="font-semibold text-gray-700 mb-2">
                    Delivery Address
                  </h4>
                  <div className="text-gray-600">
                    <p className="font-medium">{selectedOrder.address_line1}</p>
                    {selectedOrder.address_line2 && (
                      <p>{selectedOrder.address_line2}</p>
                    )}
                    <p>
                      {selectedOrder.city}, {selectedOrder.state}{" "}
                      {selectedOrder.zip_code}
                    </p>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-700 mb-2">
                    Payment Method
                  </h4>
                  <p className="text-gray-600">Cash on Delivery (COD)</p>
                  <p className="text-sm text-gray-500 mt-2">
                    Pay when you receive your order
                  </p>
                </div>
              </div>

              {/* Order Items */}
              <h3 className="text-2xl font-bold mb-4">Order Items</h3>
              <div className="overflow-x-auto mb-6">
                <table className="w-full">
                  <thead className="bg-gray-100 border-b">
                    <tr>
                      <th className="px-4 py-3 text-left text-sm font-semibold">
                        Product
                      </th>
                      <th className="px-4 py-3 text-center text-sm font-semibold">
                        Size
                      </th>
                      <th className="px-4 py-3 text-center text-sm font-semibold">
                        Quantity
                      </th>
                      <th className="px-4 py-3 text-right text-sm font-semibold">
                        Price
                      </th>
                      <th className="px-4 py-3 text-right text-sm font-semibold">
                        Total
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {orderItems.map((item) => (
                      <tr key={item.id} className="border-b hover:bg-gray-50">
                        <td className="px-4 py-3 text-sm">
                          <div className="flex items-center gap-3">
                            {item.image_url && (
                              <img
                                src={`${import.meta.env.VITE_API_BASE_URL}${item.image_url}`}
                                alt={item.name}
                                className="w-12 h-12 object-cover rounded"
                              />
                            )}
                            <span className="font-medium">{item.name}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-center text-sm">
                          {item.size || "N/A"}
                        </td>
                        <td className="px-4 py-3 text-center text-sm font-medium">
                          {item.quantity}
                        </td>
                        <td className="px-4 py-3 text-right text-sm">
                          ₹{item.price}
                        </td>
                        <td className="px-4 py-3 text-right text-sm font-semibold">
                          ₹{(item.price * item.quantity).toFixed(2)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Order Summary */}
              <div className="bg-gray-50 rounded p-4">
                <div className="flex justify-between items-center text-lg font-semibold">
                  <span>Order Total:</span>
                  <span className="text-2xl text-blue-600">
                    ₹{selectedOrder.total_amount}
                  </span>
                </div>
              </div>
            </div>
          </>
        ) : (
          <>
            {/* Orders List View */}

            {/* Statistics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
              <div className="bg-white rounded-lg shadow p-4 border-l-4 border-blue-600">
                <p className="text-gray-600 text-sm font-semibold">
                  Total Orders
                </p>
                <p className="text-3xl font-bold text-blue-600 mt-2">
                  {orderStats.total}
                </p>
              </div>
              <div className="bg-white rounded-lg shadow p-4 border-l-4 border-yellow-600">
                <p className="text-gray-600 text-sm font-semibold">
                  Processing
                </p>
                <p className="text-3xl font-bold text-yellow-600 mt-2">
                  {orderStats.pending}
                </p>
              </div>
              <div className="bg-white rounded-lg shadow p-4 border-l-4 border-blue-500">
                <p className="text-gray-600 text-sm font-semibold">
                  In Transit
                </p>
                <p className="text-3xl font-bold text-blue-500 mt-2">
                  {orderStats.shipped}
                </p>
              </div>
              <div className="bg-white rounded-lg shadow p-4 border-l-4 border-green-600">
                <p className="text-gray-600 text-sm font-semibold">Delivered</p>
                <p className="text-3xl font-bold text-green-600 mt-2">
                  {orderStats.delivered}
                </p>
              </div>
            </div>

            {/* Filters */}
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Search */}
                <div className="relative">
                  <FiSearch className="absolute left-3 top-3 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search by Order ID..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {/* Status Filter */}
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">All Orders</option>
                  <option value="confirmed">Processing</option>
                  <option value="shipped">In Transit</option>
                  <option value="delivered">Delivered</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>
            </div>

            {/* Orders Table */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              {orders.length === 0 ? (
                <div className="p-12 text-center">
                  <FiPackage className="text-gray-300 text-6xl mx-auto mb-4" />
                  <p className="text-gray-600 text-lg font-medium">
                    No orders yet
                  </p>
                  <p className="text-gray-500 mt-2">
                    Start shopping to place your first order!
                  </p>
                </div>
              ) : filteredOrders.length === 0 ? (
                <div className="p-12 text-center">
                  <p className="text-gray-600 text-lg">
                    No orders match your filters
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-100 border-b">
                      <tr>
                        <th className="px-4 py-3 text-left font-semibold text-sm">
                          Order ID
                        </th>
                        <th className="px-4 py-3 text-center font-semibold text-sm">
                          Date
                        </th>
                        <th className="px-4 py-3 text-center font-semibold text-sm">
                          Items
                        </th>
                        <th className="px-4 py-3 text-right font-semibold text-sm">
                          Amount
                        </th>
                        <th className="px-4 py-3 text-center font-semibold text-sm">
                          Status
                        </th>
                        <th className="px-4 py-3 text-center font-semibold text-sm">
                          Action
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredOrders.map((order) => (
                        <tr
                          key={order.id}
                          className="border-b hover:bg-gray-50 transition"
                        >
                          <td className="px-4 py-4">
                            <span className="font-bold text-blue-600">
                              #{order.id}
                            </span>
                          </td>
                          <td className="px-4 py-4 text-center text-sm text-gray-600">
                            {new Date(order.created_at).toLocaleDateString()}
                          </td>
                          <td className="px-4 py-4 text-center text-sm">
                            <span className="bg-gray-100 px-2 py-1 rounded text-gray-700">
                              {orderItems.length > 0
                                ? orderItems.filter(
                                    (i) => i.order_id === order.id,
                                  ).length
                                : "-"}
                            </span>
                          </td>
                          <td className="px-4 py-4 text-right font-semibold">
                            ₹{order.total_amount}
                          </td>
                          <td className="px-4 py-4 text-center">
                            <div className="flex items-center justify-center gap-2">
                              {getStatusIcon(order.status)}
                              <span
                                className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(order.status)}`}
                              >
                                {order.status.charAt(0).toUpperCase() +
                                  order.status.slice(1)}
                              </span>
                            </div>
                          </td>
                          <td className="px-4 py-4 text-center">
                            <button
                              onClick={() => handleViewOrderDetails(order.id)}
                              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition text-sm font-medium"
                            >
                              View Details
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default UserDashboard;
