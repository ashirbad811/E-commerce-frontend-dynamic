import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FiChevronRight, FiZap, FiAward, FiTruck } from "react-icons/fi";
import axios from "axios";
import ProductCard from "../components/ProductCard";

const Home = () => {
  const [categories, setCategories] = useState([]);
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch categories
        const catResponse = await axios.get(`${API_URL}/api/categories`);
        setCategories(catResponse.data);

        // Fetch featured products
        const prodResponse = await axios.get(`${API_URL}/api/products`);
        setFeaturedProducts(prodResponse.data.slice(0, 8));
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [API_URL]);

  return (
    <div className="bg-gray-50">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-blue-500 via-blue-600 to-blue-800 text-white py-12 md:py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="space-y-4 md:space-y-6">
              <h1 className="text-3xl md:text-5xl font-bold leading-tight">
                Welcome to ShopHub
              </h1>
              <p className="text-base md:text-lg text-blue-100">
                Discover millions of products at great prices. Shop now and save
                big!
              </p>
              <div className="flex flex-col sm:flex-row gap-3 pt-4">
                <Link
                  to="/products"
                  className="inline-block bg-yellow-400 text-gray-900 px-6 py-3 rounded-lg font-bold hover:bg-yellow-300 transition text-center transform hover:scale-105"
                >
                  Shop Now
                </Link>
                <Link
                  to="/products"
                  className="inline-block border-2 border-white text-white px-6 py-3 rounded-lg font-bold hover:bg-blue-700 transition text-center transform hover:scale-105"
                >
                  View Catalog
                </Link>
              </div>
            </div>
            <div className="hidden md:block">
              <img
                src="https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=500&h=400&fit=crop"
                alt="Shopping"
                className="rounded-lg shadow-xl object-cover w-full h-96"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Benefits */}
      <div className="bg-white py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-center space-x-4 text-center md:text-left p-4 rounded-lg hover:bg-blue-50 transition">
              <FiTruck className="text-blue-600 flex-shrink-0" size={32} />
              <div>
                <h3 className="font-bold text-gray-900">Free Shipping</h3>
                <p className="text-gray-600 text-sm">On orders over ₹500</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 text-center md:text-left p-4 rounded-lg hover:bg-blue-50 transition">
              <FiAward className="text-blue-600 flex-shrink-0" size={32} />
              <div>
                <h3 className="font-bold text-gray-900">Best Quality</h3>
                <p className="text-gray-600 text-sm">100% authentic products</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 text-center md:text-left p-4 rounded-lg hover:bg-blue-50 transition">
              <FiZap className="text-blue-600 flex-shrink-0" size={32} />
              <div>
                <h3 className="font-bold text-gray-900">Fast Delivery</h3>
                <p className="text-gray-600 text-sm">Delivered in 2-3 days</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Categories Carousel */}
      {categories.length > 0 && (
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900">
              Browse Categories
            </h2>
            <Link
              to="/products"
              className="flex items-center space-x-2 text-blue-600 hover:text-blue-800 font-bold group"
            >
              <span>See All</span>
              <FiChevronRight className="group-hover:translate-x-1 transition" />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {categories.map((cat) => (
              <Link
                key={cat.id}
                to={`/products?category=${cat.id}`}
                className="group bg-white rounded-xl shadow-md hover:shadow-xl hover:scale-105 transition transform duration-300 overflow-hidden"
              >
                <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 text-center">
                  <div className="text-4xl mb-3 group-hover:scale-125 transition-transform duration-300">
                    {cat.icon}
                  </div>
                  <h3 className="text-gray-900 font-bold text-sm group-hover:text-blue-600 transition line-clamp-2">
                    {cat.name}
                  </h3>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Featured Products */}
      {featuredProducts.length > 0 && (
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold text-gray-900">
                Featured Products
              </h2>
              <p className="text-gray-600 mt-1">
                Handpicked products just for you
              </p>
            </div>
            <Link
              to="/products"
              className="flex items-center space-x-2 text-blue-600 hover:text-blue-800 font-bold group"
            >
              <span>View All</span>
              <FiChevronRight className="group-hover:translate-x-1 transition" />
            </Link>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <p className="text-gray-600">Loading products...</p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Deals & Offers Banner */}
      <div className="bg-gradient-to-r from-red-500 to-red-600 text-white py-8 md:py-12 mt-12 mx-4 md:mx-auto rounded-lg max-w-7xl">
        <div className="px-4 py-6 text-center">
          <div className="text-3xl md:text-4xl font-bold mb-2">
            🎉 Special Offers
          </div>
          <p className="text-base md:text-lg text-red-100 mb-4">
            Get up to 50% off on selected items
          </p>
          <Link
            to="/products"
            className="inline-block bg-white text-red-600 px-6 py-3 rounded-lg font-bold hover:bg-red-50 transition transform hover:scale-105"
          >
            Shop Deals Now
          </Link>
        </div>
      </div>

      {/* Newsletter CTA Section */}
      <div className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-gray-900 py-12 md:py-16 mt-12">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Get Exclusive Deals & Offers
          </h2>
          <p className="text-base md:text-lg mb-6 text-gray-800">
            Subscribe to our newsletter for the latest updates and special
            discounts
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center max-w-md mx-auto">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-600"
            />
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-bold transition transform hover:scale-105">
              Subscribe
            </button>
          </div>
        </div>
      </div>

      {/* Why Shop With Us */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-8 text-center">
          Why Shop With Us?
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition">
            <div className="text-4xl mb-4">💳</div>
            <h3 className="font-bold text-lg mb-2">Secure Payment</h3>
            <p className="text-gray-600">
              Multiple payment options with secure checkout
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition">
            <div className="text-4xl mb-4">🔄</div>
            <h3 className="font-bold text-lg mb-2">Easy Returns</h3>
            <p className="text-gray-600">
              30-day return policy for peace of mind
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition">
            <div className="text-4xl mb-4">💬</div>
            <h3 className="font-bold text-lg mb-2">24/7 Support</h3>
            <p className="text-gray-600">Customer support team ready to help</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
