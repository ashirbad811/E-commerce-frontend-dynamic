import React, { useState, useContext } from "react";
import { Link } from "react-router-dom";
import AuthModal from "../components/AuthModal";
import NewArrivals from "../components/NewArrivals";
import PopularProducts from "../components/PopularProducts";
import { AuthContext } from "../context/AuthContext";

const Home = () => {
  const [showAuthModal, setShowAuthModal] = useState(false);
  const { user } = useContext(AuthContext);

  return (
    <div className="bg-white">
      {/* Auth Modal */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
      />

      {/* Premium Banner Section */}
      <section className="relative bg-gradient-to-r from-blue-600 via-blue-700 to-blue-800 text-white py-20">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-white rounded-full -mr-48 -mt-48"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-white rounded-full -ml-48 -mb-48"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              Welcome to TeeStore
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-blue-100">
              Custom and branded t-shirts crafted for you
            </p>
            <p className="text-lg mb-10 text-blue-50">
              Discover premium quality, affordable prices, and exclusive designs
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/shop"
                className="bg-white text-blue-600 px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-100 transition transform hover:scale-105 shadow-lg"
              >
                Shop Now
              </Link>
              {!user && (
                <button
                  onClick={() => setShowAuthModal(true)}
                  className="border-2 border-white text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-white hover:text-blue-600 transition transform hover:scale-105"
                >
                  Sign In / Sign Up
                </button>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="bg-white rounded-lg p-8 shadow-md hover:shadow-lg transition text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">🚚</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Fast Delivery</h3>
              <p className="text-gray-600">
                Get your products delivered quickly to your doorstep
              </p>
            </div>

            {/* Feature 2 */}
            <div className="bg-white rounded-lg p-8 shadow-md hover:shadow-lg transition text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">💯</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Quality Assured</h3>
              <p className="text-gray-600">
                Premium materials and excellent craftsmanship
              </p>
            </div>

            {/* Feature 3 */}
            <div className="bg-white rounded-lg p-8 shadow-md hover:shadow-lg transition text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">🛡️</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Secure Payment</h3>
              <p className="text-gray-600">
                Safe and encrypted transactions for your peace of mind
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* New Arrivals Section */}
      <NewArrivals />

      {/* Popular Products Section */}
      <PopularProducts />

      {/* Call to Action Section */}
      <section className="py-16 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">
            Exclusive Offers Waiting For You
          </h2>
          <p className="text-xl mb-8 text-purple-100 max-w-2xl mx-auto">
            Sign up today and get 20% off on your first purchase. Limited time
            offer!
          </p>
          {!user && (
            <button
              onClick={() => setShowAuthModal(true)}
              className="bg-white text-purple-600 px-10 py-4 rounded-lg font-bold text-lg hover:bg-gray-100 transition transform hover:scale-105 shadow-lg"
            >
              Join Now & Get 20% Off
            </button>
          )}
          {user && (
            <Link
              to="/shop"
              className="inline-block bg-white text-purple-600 px-10 py-4 rounded-lg font-bold text-lg hover:bg-gray-100 transition transform hover:scale-105 shadow-lg"
            >
              Start Shopping
            </Link>
          )}
        </div>
      </section>
    </div>
  );
};

export default Home;
