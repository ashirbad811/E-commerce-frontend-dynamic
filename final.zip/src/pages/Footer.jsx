import React from 'react';
import { FiFacebook, FiTwitter, FiInstagram, FiLinkedin, FiMail, FiPhone, FiMapPin } from 'react-icons/fi';
import { FaTshirt } from 'react-icons/fa';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand Column */}
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <FaTshirt className="text-3xl text-blue-400" />
              <span className="text-2xl font-bold">Tee<span className="text-blue-400">Store</span></span>
            </div>
            <p className="text-gray-400 mb-6">
              Premium custom t-shirts with exceptional quality and unique designs. 
              Wear your style with confidence.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="bg-gray-800 hover:bg-blue-600 w-10 h-10 rounded-full flex items-center justify-center transition-colors">
                <FiFacebook className="text-xl" />
              </a>
              <a href="#" className="bg-gray-800 hover:bg-blue-400 w-10 h-10 rounded-full flex items-center justify-center transition-colors">
                <FiTwitter className="text-xl" />
              </a>
              <a href="#" className="bg-gray-800 hover:bg-pink-600 w-10 h-10 rounded-full flex items-center justify-center transition-colors">
                <FiInstagram className="text-xl" />
              </a>
              <a href="#" className="bg-gray-800 hover:bg-blue-700 w-10 h-10 rounded-full flex items-center justify-center transition-colors">
                <FiLinkedin className="text-xl" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  All Products
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  Custom Design
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  Summer Collection
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  Sale
                </a>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-xl font-bold mb-6">Support</h3>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  Contact Us
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  FAQ
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  Shipping Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  Return & Refund
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  Size Guide
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-xl font-bold mb-6">Contact Info</h3>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <FiMapPin className="text-blue-400 mt-1" />
                <span className="text-gray-400">
                  123 Fashion Street, Style City<br />
                  New York, NY 10001
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <FiPhone className="text-blue-400" />
                <span className="text-gray-400">+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center space-x-3">
                <FiMail className="text-blue-400" />
                <span className="text-gray-400">support@teestore.com</span>
              </div>
            </div>

            {/* Newsletter */}
            <div className="mt-8">
              <h4 className="font-bold mb-4">Stay Updated</h4>
              <div className="flex">
                <input
                  type="email"
                  placeholder="Your email"
                  className="bg-gray-800 text-white px-4 py-3 rounded-l-lg flex-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button className="bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-r-lg font-bold transition-colors">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Payment Methods */}
        <div className="border-t border-gray-800 pt-8 mb-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-6 md:mb-0">
              <h4 className="font-bold mb-4">Secure Payment Methods</h4>
              <div className="flex space-x-4">
                <div className="bg-gray-800 px-4 py-2 rounded-lg">Visa</div>
                <div className="bg-gray-800 px-4 py-2 rounded-lg">MasterCard</div>
                <div className="bg-gray-800 px-4 py-2 rounded-lg">PayPal</div>
                <div className="bg-gray-800 px-4 py-2 rounded-lg">Stripe</div>
              </div>
            </div>
            <div className="text-center md:text-right">
              <div className="text-2xl font-bold text-blue-400 mb-2">100% Secure</div>
              <div className="text-gray-400">SSL Encrypted Payments</div>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="text-center pt-8 border-t border-gray-800">
          <p className="text-gray-400">
            &copy; {currentYear} TeeStore. All rights reserved. | 
            <a href="#" className="text-blue-400 hover:text-blue-300 ml-2">Privacy Policy</a> | 
            <a href="#" className="text-blue-400 hover:text-blue-300 ml-2">Terms of Service</a>
          </p>
          <p className="text-gray-500 text-sm mt-2">
            Designed with ❤️ for t-shirt lovers everywhere
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;