import React, { useContext, useState, useEffect } from "react";
import { AuthContext } from "../context/AuthContext";
import axios from "axios";
import Swal from "sweetalert2";

const UserDashboard = () => {
  const { user } = useContext(AuthContext);
  const [orders, setOrders] = useState([]);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [orderItems, setOrderItems] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/api/orders`,
        {
          withCredentials: true,
        },
      );
      setOrders(response.data);
    } catch (err) {
      console.error("Error fetching orders:", err);
      Swal.fire("Error", "Failed to fetch orders", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleViewOrderDetails = async (orderId) => {
    try {
      const response = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/api/orders/${orderId}`,
        {
          withCredentials: true,
        },
      );
      setSelectedOrder(response.data);
      setOrderItems(response.data.items || []);
    } catch (err) {
      console.error("Error fetching order details:", err);
      Swal.fire("Error", "Failed to fetch order details", "error");
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "delivered":
        return "bg-green-100 text-green-800";
      case "shipped":
        return "bg-blue-100 text-blue-800";
      case "confirmed":
        return "bg-yellow-100 text-yellow-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Welcome, {user?.name}!</h2>
        <p className="text-gray-600">Email: {user?.email}</p>
      </div>

      {selectedOrder ? (
        <div className="bg-white p-6 rounded-lg shadow-md">
          <button
            onClick={() => setSelectedOrder(null)}
            className="mb-4 text-blue-600 hover:text-blue-800 font-semibold"
          >
            ← Back to Orders
          </button>

          <h3 className="text-2xl font-bold mb-4">Order #{selectedOrder.id}</h3>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div>
              <p className="text-gray-600 text-sm">Order Date</p>
              <p className="font-semibold">
                {new Date(selectedOrder.created_at).toLocaleDateString()}
              </p>
            </div>
            <div>
              <p className="text-gray-600 text-sm">Status</p>
              <span
                className={`inline-block px-3 py-1 rounded-full text-sm font-semibold ${getStatusColor(selectedOrder.status)}`}
              >
                {selectedOrder.status.toUpperCase()}
              </span>
            </div>
            <div>
              <p className="text-gray-600 text-sm">Delivery Address</p>
              <p className="font-semibold">{selectedOrder.address_line1}</p>
              <p className="text-sm text-gray-600">
                {selectedOrder.city}, {selectedOrder.zip_code}
              </p>
            </div>
            <div>
              <p className="text-gray-600 text-sm">Payment Method</p>
              <p className="font-semibold">Cash on Delivery (COD)</p>
            </div>
          </div>

          <h4 className="font-bold text-lg mb-3">Order Items</h4>
          <div className="overflow-x-auto mb-6">
            <table className="w-full">
              <thead className="bg-gray-100 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-semibold">
                    Product
                  </th>
                  <th className="px-4 py-3 text-center text-sm font-semibold">
                    Quantity
                  </th>
                  <th className="px-4 py-3 text-right text-sm font-semibold">
                    Price
                  </th>
                  <th className="px-4 py-3 text-right text-sm font-semibold">
                    Total
                  </th>
                </tr>
              </thead>
              <tbody>
                {orderItems.map((item) => (
                  <tr key={item.id} className="border-b hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm">
                      <div className="flex items-center gap-3">
                        {item.image_url && (
                          <img
                            src={`http://localhost:5000${item.image_url}`}
                            alt={item.name}
                            className="w-12 h-12 object-cover rounded"
                          />
                        )}
                        <span>{item.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-center text-sm">
                      {item.quantity}
                    </td>
                    <td className="px-4 py-3 text-right text-sm">
                      ${item.price}
                    </td>
                    <td className="px-4 py-3 text-right text-sm font-semibold">
                      ${(item.price * item.quantity).toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="border-t pt-4 flex justify-end">
            <div>
              <p className="text-gray-600 mb-2">Order Total:</p>
              <p className="text-2xl font-bold">
                ${selectedOrder.total_amount}
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-semibold mb-4">Your Orders</h3>

          {loading ? (
            <p className="text-gray-600 text-center py-8">Loading orders...</p>
          ) : orders.length === 0 ? (
            <p className="text-gray-600 text-center py-8">
              You haven't placed any orders yet.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-100 border-b">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-semibold">
                      Order ID
                    </th>
                    <th className="px-4 py-3 text-left text-sm font-semibold">
                      Date
                    </th>
                    <th className="px-4 py-3 text-left text-sm font-semibold">
                      Amount
                    </th>
                    <th className="px-4 py-3 text-left text-sm font-semibold">
                      Status
                    </th>
                    <th className="px-4 py-3 text-left text-sm font-semibold">
                      Delivery To
                    </th>
                    <th className="px-4 py-3 text-center text-sm font-semibold">
                      Action
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((order) => (
                    <tr key={order.id} className="border-b hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm font-semibold">
                        #{order.id}
                      </td>
                      <td className="px-4 py-3 text-sm">
                        {new Date(order.created_at).toLocaleDateString()}
                      </td>
                      <td className="px-4 py-3 text-sm font-semibold">
                        ${order.total_amount}
                      </td>
                      <td className="px-4 py-3 text-sm">
                        <span
                          className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(order.status)}`}
                        >
                          {order.status.toUpperCase()}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm">
                        <p className="font-semibold">{order.city}</p>
                        <p className="text-xs text-gray-600">
                          {order.address_line1?.substring(0, 30)}...
                        </p>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button
                          onClick={() => handleViewOrderDetails(order.id)}
                          className="text-blue-600 hover:text-blue-800 font-semibold text-sm"
                        >
                          View Details
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default UserDashboard;
